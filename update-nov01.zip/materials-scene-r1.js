import * as THREE from './vendor/three/build/three.module.js';
import {GLTFLoader} from './vendor/three/examples/jsm/loaders/GLTFLoader.js';
import {stepMaterialMotion} from './materials-motion.mjs?v=materials-r6';

export async function createMaterialScene(stage,callbacks){
  const renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'high-performance'});
  renderer.outputColorSpace=THREE.SRGBColorSpace;
  renderer.toneMapping=THREE.AgXToneMapping;
  renderer.toneMappingExposure=.95;
  renderer.shadowMap.enabled=true;
  renderer.shadowMap.type=THREE.VSMShadowMap;
  renderer.shadowMap.autoUpdate=false;renderer.shadowMap.needsUpdate=true;
  const canvas=renderer.domElement;
  canvas.tabIndex=0;canvas.setAttribute('role','img');
  canvas.setAttribute('aria-label','Трёхмерная модель шахматного стола «Турнир»');
  canvas.setAttribute('aria-describedby',stage.dataset.helpId);
  stage.append(canvas);
  const world=new THREE.Scene();
  const camera=new THREE.OrthographicCamera(-1.5,1.5,1,-1,.1,30);
  const viewDirection=new THREE.Vector3(2.9,2.3,3.4).normalize();
  const metalDirection=new THREE.Vector3(3.9,1.5,2.7).normalize(),currentDirection=new THREE.Vector3();
  const viewTarget=new THREE.Vector3(0,.03,0);
  camera.position.copy(viewDirection).multiplyScalar(6).add(viewTarget);camera.lookAt(viewTarget);

  // Large neutral studio panels give the painted frame broad, quiet reflections.
  const studio=new THREE.Scene();studio.background=new THREE.Color(.82,.84,.8);
  const panels=[];
  for(const [position,scale,intensity] of [
    [[-3,3,1],[2.2,4,1],3.2],[[3,2,-2],[1.5,3.5,1],1.8],[[0,4,0],[4,1,4],2.2]
  ]){
    const panel=new THREE.Mesh(new THREE.BoxGeometry(...scale),new THREE.MeshBasicMaterial({color:new THREE.Color().setScalar(intensity)}));
    panel.position.set(...position);studio.add(panel);panels.push(panel);
  }
  const generator=new THREE.PMREMGenerator(renderer);
  const environment=generator.fromScene(studio,.045);world.environment=environment.texture;
  generator.dispose();panels.forEach(panel=>{panel.geometry.dispose();panel.material.dispose();});
  const ambient=new THREE.HemisphereLight(0xfffcf1,0x9da99d,.9);world.add(ambient);
  const key=new THREE.DirectionalLight(0xfffaf0,2.2);key.position.set(-3,5,4);key.castShadow=true;
  key.shadow.mapSize.set(1024,1024);key.shadow.camera.left=-2.1;key.shadow.camera.right=2.1;key.shadow.camera.top=2.1;key.shadow.camera.bottom=-2.1;
  key.shadow.camera.near=.1;key.shadow.camera.far=15;key.shadow.normalBias=.004;key.shadow.bias=-.00008;key.shadow.radius=9;key.shadow.blurSamples=12;
  world.add(key);
  const fill=new THREE.DirectionalLight(0xe6eee8,.65);fill.position.set(4,2,-3);world.add(fill);
  const ground=new THREE.Mesh(new THREE.PlaneGeometry(20,20),new THREE.ShadowMaterial({color:0x324436,opacity:.15}));
  ground.rotation.x=-Math.PI/2;ground.position.y=-.378;ground.receiveShadow=true;world.add(ground);

  let gltf;
  try{
    gltf=await new GLTFLoader().loadAsync(callbacks.source,event=>callbacks.onProgress(event.total?Math.min(99,Math.round(100*event.loaded/event.total)):0));
  }catch(error){renderer.dispose();canvas.remove();environment.dispose();ground.geometry.dispose();ground.material.dispose();throw error;}
  const rig=new THREE.Group();world.add(rig);
  const model=gltf.scene;model.position.set(0,-.375,0);rig.add(model);
  const parts=[],materialTextures=new Set();let triangles=0;
  const metalUniforms={uMetalFocus:{value:0},uMetalBand:{value:-.2},uMetalSweepStrength:{value:0}};
  let metalBounds={min:0,max:.7};
  model.traverse(part=>{
    if(!part.isMesh)return;
    part.castShadow=true;part.receiveShadow=true;
    part.geometry.computeBoundingBox();
    const kind=part.name.startsWith('wood')?'wood':part.name.includes('concrete')?'concrete':'metal';
    part.userData.materialKind=kind;
    part.userData.basePosition=part.position.clone();
    part.userData.offset=new THREE.Vector3(0,kind==='concrete'?.2:kind==='wood'?.17:0,0);
    part.userData.liftMotion={value:0,velocity:0};
    part.material=part.material.clone();
    for(const value of Object.values(part.material))if(value?.isTexture)materialTextures.add(value);
    part.material.envMapIntensity=.6;
    part.userData.baseColor=part.material.color.clone();
    part.userData.baseRoughness=part.material.roughness;
    if(kind==='metal'){
      metalBounds={min:part.geometry.boundingBox.min.y,max:part.geometry.boundingBox.max.y};
      part.material.onBeforeCompile=shader=>{
        Object.assign(shader.uniforms,metalUniforms);
        shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying float vMetalHeight;');
        shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvMetalHeight=position.y;');
        shader.fragmentShader=shader.fragmentShader.replace('#include <common>',`#include <common>
uniform float uMetalFocus;
uniform float uMetalBand;
uniform float uMetalSweepStrength;
varying float vMetalHeight;`);
        shader.fragmentShader=shader.fragmentShader.replace('#include <emissivemap_fragment>',`#include <emissivemap_fragment>
float metalBandDistance=(vMetalHeight-uMetalBand)/0.075;
float metalBand=exp(-metalBandDistance*metalBandDistance);
float metalRim=pow(1.0-abs(dot(normal,normalize(vViewPosition))),2.4);
totalEmissiveRadiance+=vec3(0.72,0.77,0.68)*(metalBand*uMetalSweepStrength+metalRim*uMetalFocus*0.13);`);
        stage.closest('[data-material-explorer]').dataset.metalEffect='ready';
      };
      part.material.customProgramCacheKey=()=> 'artcolor-metal-glint-r5';
    }
    parts.push(part);triangles+=(part.geometry.index?.count||part.geometry.attributes.position.count)/3;
  });
  const textureLimit=window.matchMedia('(max-width: 600px)').matches||(navigator.deviceMemory&&navigator.deviceMemory<=4)?1024:2048;
  if(textureLimit<2048){
    const bitmaps=new Set();
    for(const texture of materialTextures){
      const image=texture.image;
      if(!image||Math.max(image.width,image.height)<=textureLimit)continue;
      const resized=document.createElement('canvas'),ratio=textureLimit/Math.max(image.width,image.height);
      resized.width=Math.round(image.width*ratio);resized.height=Math.round(image.height*ratio);
      const context=resized.getContext('2d');context.imageSmoothingQuality='high';context.drawImage(image,0,0,resized.width,resized.height);
      texture.image=resized;texture.needsUpdate=true;bitmaps.add(image);
    }
    bitmaps.forEach(bitmap=>bitmap.close?.());
  }
  stage.closest('[data-material-explorer]').dataset.modelTextureLimit=String(textureLimit);
  // Base-position hit areas keep a raised detail selectable under the pointer.
  const pickProxies=parts.map(part=>{
    const proxy=new THREE.Mesh(part.geometry,part.material);
    proxy.name=part.name;proxy.position.copy(part.userData.basePosition);
    proxy.quaternion.copy(part.quaternion);proxy.scale.copy(part.scale);proxy.visible=false;
    proxy.userData.materialKind=part.userData.materialKind;model.add(proxy);return proxy;
  });
  let state={part:null,material:null},yaw=0,targetYaw=0,pitch=0,targetPitch=0;
  const metalFocus={value:0,velocity:0},metalGlow={value:0,velocity:0};
  const sweepDuration=1800;let sweepElapsed=sweepDuration;
  let frame=0,lastTime=0,disposed=false,visible=true,reducedMotion=false,aspect=1;
  const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
  const activeColor=new THREE.Color();
  function request(){if(!disposed&&visible&&!document.hidden&&!frame)frame=requestAnimationFrame(render);}
  function resize(){
    const width=stage.clientWidth,height=stage.clientHeight;
    if(!width||!height)return;
    aspect=width/height;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2,Math.sqrt(2800000/(width*height))));
    renderer.setSize(width,height,false);
    const heightInWorld=Math.max(1.88,2.4/aspect);
    camera.left=-heightInWorld*aspect/2;camera.right=heightInWorld*aspect/2;camera.top=heightInWorld/2;camera.bottom=-heightInWorld/2;
    camera.updateProjectionMatrix();request();
  }
  function render(time){
    frame=0;if(disposed||!visible||document.hidden)return;
    const delta=Math.min(64,lastTime?time-lastTime:16);lastTime=time;
    const factor=1-Math.exp(-delta/230);
    let shadowChanged=Math.abs(yaw-targetYaw)>.0004||Math.abs(pitch-targetPitch)>.0004;
    yaw=THREE.MathUtils.lerp(yaw,targetYaw,factor);pitch=THREE.MathUtils.lerp(pitch,targetPitch,factor);
    rig.rotation.set(pitch,yaw,0);
    let changing=Math.abs(yaw-targetYaw)>.0004||Math.abs(pitch-targetPitch)>.0004;
    const metalTarget=state.part==='metal'&&state.pinned?(reducedMotion?.45:1):0;
    changing=stepMaterialMotion(metalFocus,metalTarget,delta)||changing;
    changing=stepMaterialMotion(metalGlow,state.part==='metal'?1:0,delta)||changing;
    if(sweepElapsed<sweepDuration){sweepElapsed=Math.min(sweepDuration,sweepElapsed+delta);changing=true;}
    const sweepProgress=sweepElapsed/sweepDuration;
    metalUniforms.uMetalFocus.value=metalGlow.value;
    metalUniforms.uMetalBand.value=THREE.MathUtils.lerp(metalBounds.min-.15,metalBounds.max+.15,sweepProgress);
    metalUniforms.uMetalSweepStrength.value=Math.sin(Math.PI*sweepProgress)*metalGlow.value*(reducedMotion?.55:.72);
    for(const part of parts){
      const selected=part.name===state.part,liftTarget=selected?1:0;
      const previousLift=part.userData.liftMotion.value;
      changing=stepMaterialMotion(part.userData.liftMotion,liftTarget,delta)||changing;
      if(Math.abs(previousLift-part.userData.liftMotion.value)>.000001&&part.userData.offset.lengthSq()>0)shadowChanged=true;
      part.position.copy(part.userData.basePosition).addScaledVector(part.userData.offset,part.userData.liftMotion.value*(reducedMotion?.7:1));
      const brightness=state.part?(selected?(state.part==='metal'?1.14:1.025):(state.part==='metal'?.88:.94)):1;
      activeColor.copy(part.userData.baseColor).multiplyScalar(brightness);
      if(Math.abs(part.material.color.r-activeColor.r)+Math.abs(part.material.color.g-activeColor.g)+Math.abs(part.material.color.b-activeColor.b)>.001)changing=true;
      part.material.color.lerp(activeColor,factor);
      const reflection=selected&&state.part==='metal'?1.5:.6;
      if(Math.abs(part.material.envMapIntensity-reflection)>.001)changing=true;
      part.material.envMapIntensity=THREE.MathUtils.lerp(part.material.envMapIntensity,reflection,factor);
      const roughness=part.userData.baseRoughness*(selected&&state.part==='metal'?.75:1);
      if(Math.abs(part.material.roughness-roughness)>.001)changing=true;
      part.material.roughness=THREE.MathUtils.lerp(part.material.roughness,roughness,factor);
    }
    rig.updateMatrixWorld(true);
    currentDirection.copy(viewDirection).lerp(metalDirection,metalFocus.value).normalize();
    camera.position.copy(currentDirection).multiplyScalar(6).add(viewTarget);camera.lookAt(viewTarget);
    camera.zoom=1+metalFocus.value*.06;camera.updateProjectionMatrix();
    if(shadowChanged)renderer.shadowMap.needsUpdate=true;
    renderer.render(world,camera);
    if(changing)request();else lastTime=0;
  }
  const resizer=new ResizeObserver(resize);resizer.observe(stage);resize();
  const events=[];
  const listen=(target,event,handler,options)=>{target.addEventListener(event,handler,options);events.push(()=>target.removeEventListener(event,handler,options));};
  function pick(clientX,clientY){
    const rect=canvas.getBoundingClientRect();
    pointer.set((clientX-rect.left)/rect.width*2-1,-(clientY-rect.top)/rect.height*2+1);
    raycaster.setFromCamera(pointer,camera);
    return raycaster.intersectObjects([...parts,...pickProxies],false)[0]?.object.name||null;
  }
  let drag=null,hovered;
  listen(canvas,'pointerdown',event=>{
    if(event.button>0)return;
    drag={id:event.pointerId,x:event.clientX,y:event.clientY,lastX:event.clientX,lastY:event.clientY,moved:false};
    if(event.pointerType==='mouse'){canvas.setPointerCapture(event.pointerId);canvas.focus({preventScroll:true});event.preventDefault();}
  });
  listen(canvas,'pointermove',event=>{
    if(drag&&event.pointerId===drag.id){
      const dx=event.clientX-drag.x,dy=event.clientY-drag.y;
      if(!drag.moved&&Math.hypot(dx,dy)>6){
        if(event.pointerType==='touch'&&Math.abs(dy)>Math.abs(dx)){drag=null;return;}
        drag.moved=true;canvas.setPointerCapture(event.pointerId);
      }
      if(drag.moved){targetYaw+=(event.clientX-drag.lastX)*.007;targetPitch=THREE.MathUtils.clamp(targetPitch+(event.clientY-drag.lastY)*.002,-.16,.18);request();}
      drag.lastX=event.clientX;drag.lastY=event.clientY;
    }else if(event.pointerType==='mouse'){
      const part=pick(event.clientX,event.clientY);
      canvas.style.cursor=part?'pointer':'grab';
      if(part!==hovered){hovered=part;callbacks.onPreview(part);}
    }
  });
  listen(canvas,'pointerup',event=>{
    if(!drag||drag.id!==event.pointerId)return;
    const moved=drag.moved;drag=null;
    if(canvas.hasPointerCapture(event.pointerId))canvas.releasePointerCapture(event.pointerId);
    if(!moved){const part=pick(event.clientX,event.clientY);if(part)callbacks.onSelect(part);else callbacks.onReset();}
  });
  listen(canvas,'pointercancel',()=>{drag=null;});
  listen(canvas,'pointerleave',()=>{hovered=null;callbacks.onPreview(null);});
  listen(canvas,'keydown',event=>{
    if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();targetYaw+=(event.key==='ArrowLeft'?-1:1)*.2;request();}
    else if(event.key==='ArrowUp'||event.key==='ArrowDown'){event.preventDefault();targetPitch=THREE.MathUtils.clamp(targetPitch+(event.key==='ArrowUp'?-1:1)*.06,-.16,.18);request();}
  });
  listen(document,'visibilitychange',()=>{lastTime=0;if(document.hidden){cancelAnimationFrame(frame);frame=0;}else request();});
  listen(canvas,'webglcontextlost',event=>{event.preventDefault();stage.closest('[data-material-explorer]').dataset.modelState='fallback';});
  request();
  return {
    triangles:Math.round(triangles),parts:parts.length,
    setState(next,reduced){
      if(next.part==='metal'&&(state.part!=='metal'||next.pinned&&!state.pinned))sweepElapsed=0;
      state=next;reducedMotion=reduced;request();
    },
    resetView(reduced){targetYaw=targetPitch=0;reducedMotion=reduced;request();},
    setVisible(value){visible=value;lastTime=0;if(!value){cancelAnimationFrame(frame);frame=0;}else request();},
    dispose(){
      disposed=true;cancelAnimationFrame(frame);resizer.disconnect();events.forEach(remove=>remove());
      const textures=new Set();parts.forEach(part=>{part.geometry.dispose();for(const value of Object.values(part.material))if(value?.isTexture)textures.add(value);part.material.dispose();});
      textures.forEach(texture=>{texture.source?.data?.close?.();texture.dispose();});
      environment.dispose();ground.geometry.dispose();ground.material.dispose();renderer.dispose();canvas.remove();
    }
  };
}
