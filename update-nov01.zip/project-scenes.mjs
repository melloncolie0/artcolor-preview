// Each visible catalog item has a point; repeated models share one detail card.
export const projectScenes = {
  "finnish": {
    "image": "/artcolor-preview/assets/project-scenes/finnish-gamma-r5.webp",
    "alt": "Объёмная визуализация двора Финского квартала: кирпичные дома, озеленение и деревянная мебель",
    "items": [
      {
        "id": "teremok",
        "title": "Беседка «Теремок»",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-171.webp",
        "description": "Две скамьи и стол под фигурным навесом. Комплект для зон отдыха во дворе.",
        "href": "/artcolor-preview/product/ac-171/",
        "linkLabel": "Модель «Теремок» в каталоге",
        "points": [
          {
            "x": 21.8,
            "y": 62.3
          },
          {
            "x": 32.3,
            "y": 66.5
          }
        ],
        "photoAlt": "Скамейка-пергола «Теремок». Студийное изображение из каталога",
        "photoLabel": "Изделие из каталога",
        "photoFit": "contain"
      },
      {
        "id": "pergolas",
        "title": "Пергола «Гамма»",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-172.webp",
        "description": "Открытый навес на трёх задних стойках. Горизонтальные деревянные рейки и скамья на двух бетонных опорах.",
        "href": "/artcolor-preview/product/ac-172/",
        "linkLabel": "Модель «Гамма» в каталоге",
        "points": [
          {
            "x": 74.3,
            "y": 53.6
          },
          {
            "x": 84.4,
            "y": 57
          }
        ],
        "photoAlt": "Пергола «Гамма». Студийное изображение из каталога",
        "photoLabel": "Изделие из каталога",
        "photoFit": "contain"
      },
      {
        "id": "lounger",
        "title": "Шезлонг",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-251.webp",
        "description": "Изогнутый деревянный настил на металлическом каркасе. В каталоге подобрана похожая модель.",
        "href": "/artcolor-preview/product/ac-251/",
        "linkLabel": "Похожая модель «Мистраль»",
        "points": [
          {
            "x": 55,
            "y": 82
          }
        ],
        "photoAlt": "Шезлонг «Мистраль». Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      },
      {
        "id": "bin",
        "title": "Урна с навесом",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-107.webp",
        "description": "Деревянные рейки, металлический каркас и навес. В каталоге подобрана похожая модель.",
        "href": "/artcolor-preview/product/ac-107/",
        "linkLabel": "Похожая модель «Вижен»",
        "photoFit": "contain",
        "points": [
          {
            "x": 38.5,
            "y": 82
          }
        ],
        "photoAlt": "Урна «Вижен». Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога"
      },
      {
        "id": "path-benches",
        "title": "Скамьи вдоль дорожек",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-009.webp",
        "description": "Скамьи на металлических опорах. Для этого типа подобрана похожая модель «Новый город». Исполнение уточним по проекту.",
        "href": "/artcolor-preview/product/ac-009/",
        "linkLabel": "Похожая модель «Новый город»",
        "points": [
          {
            "x": 34.7,
            "y": 50.3
          },
          {
            "x": 38.7,
            "y": 48.2
          },
          {
            "x": 47.8,
            "y": 45
          },
          {
            "x": 49.8,
            "y": 41.5
          },
          {
            "x": 72.3,
            "y": 47.3
          }
        ],
        "photoAlt": "Скамейка «Новый город» со спинкой. Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      }
    ]
  },
  "happiness": {
    "image": "/artcolor-preview/assets/project-scenes/happiness-updated-r8.webp",
    "alt": "Объёмная визуализация двора ЖК Счастье: светлые дома с яркими фасадами и скульптурные деревянные беседки",
    "items": [
      {
        "id": "lameli",
        "title": "Беседки «Ламели»",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-178.webp",
        "description": "Открытая беседка из деревянных ламелей с кольцевой скамьёй внутри.",
        "href": "/artcolor-preview/product/ac-178/",
        "linkLabel": "Модель «Ламели» в каталоге",
        "points": [
          {
            "x": 22,
            "y": 54.5
          },
          {
            "x": 40.5,
            "y": 64
          }
        ],
        "photoAlt": "Беседки Ламели. Студийное изображение из каталога",
        "photoLabel": "Изделие из каталога",
        "photoFit": "contain"
      },
      {
        "id": "benches",
        "title": "Скамьи на бетонных опорах",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-048.webp",
        "description": "Деревянное сиденье и спинка на бетонных опорах. В каталоге подобрана похожая модель, размеры на объекте требуют уточнения.",
        "href": "/artcolor-preview/product/ac-048/",
        "linkLabel": "Похожая модель «Форт»",
        "points": [
          {
            "x": 71.4,
            "y": 67.4
          },
          {
            "x": 81.2,
            "y": 71.3
          }
        ],
        "photoAlt": "Скамейка «Форт» 1800. Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      },
      {
        "id": "bins",
        "title": "Круглые урны",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-114.webp",
        "description": "Деревянные рейки и круглое бетонное основание. В каталоге подобрана похожая модель.",
        "href": "/artcolor-preview/product/ac-114/",
        "linkLabel": "Похожая модель «Тамар»",
        "points": [
          {
            "x": 65.3,
            "y": 68.4
          },
          {
            "x": 84.9,
            "y": 74.2
          }
        ],
        "photoAlt": "Урна «Тамар». Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      }
    ]
  },
  "apple-gardens": {
    "image": "/artcolor-preview/assets/project-scenes/apple-gardens-table-r3.webp",
    "alt": "Визуализация Яблоневых садов: светлые высотные фасады, радиусная пергола, скамьи, урны и теннисный стол",
    "items": [
      {
        "id": "benches",
        "title": "Скамья со спинкой",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-046.webp",
        "description": "Скамьи с деревянной спинкой на бетонных опорах. В каталоге подобрана похожая модель, точное исполнение требует уточнения.",
        "href": "/artcolor-preview/product/ac-046/",
        "linkLabel": "Похожая модель «Форт»",
        "points": [
          {
            "x": 24.1,
            "y": 51.5
          }
        ],
        "photoAlt": "Скамейка «Форт» 1700 со спинкой. Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      },
      {
        "id": "bins",
        "title": "Круглые урны",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-114.webp",
        "description": "Урны из деревянных реек на круглом бетонном основании. В каталоге подобрана похожая модель.",
        "href": "/artcolor-preview/product/ac-114/",
        "linkLabel": "Похожая модель «Тамар»",
        "points": [
          {
            "x": 14.8,
            "y": 59.1
          },
          {
            "x": 47.2,
            "y": 40.5
          },
          {
            "x": 84.2,
            "y": 46.1
          }
        ],
        "photoAlt": "Урна «Тамар». Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      },
      {
        "id": "pergola",
        "title": "Радиусная пергола",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-151.webp",
        "description": "Радиусный реечный навес для зоны отдыха. В каталоге подобрана похожая пергола.",
        "href": "/artcolor-preview/product/ac-151/",
        "linkLabel": "Похожая пергола «Радуга»",
        "points": [
          {
            "x": 45.2,
            "y": 24.8
          }
        ],
        "photoAlt": "Пергола «Радуга» радиусная. Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      },
      {
        "id": "table",
        "title": "Теннисный стол",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-146.webp",
        "description": "Бетонная столешница и металлическая сетка. В каталоге подобрана похожая модель.",
        "href": "/artcolor-preview/product/ac-146/",
        "linkLabel": "Похожая модель «Партия»",
        "points": [
          {
            "x": 81,
            "y": 64
          }
        ],
        "photoAlt": "Теннисный стол «Партия» антивандальный. Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      },
      {
        "id": "backless-benches",
        "title": "Скамьи без спинки",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-047.webp",
        "description": "Деревянный настил на бетонных опорах. В каталоге подобрана похожая скамья «Форт» без спинки.",
        "href": "/artcolor-preview/product/ac-047/",
        "linkLabel": "Похожая модель «Форт» без спинки",
        "points": [
          {
            "x": 34.7,
            "y": 44.6
          },
          {
            "x": 51.6,
            "y": 38.1
          }
        ],
        "photoAlt": "Скамейка «Форт» 1700 без спинки. Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      }
    ]
  },
  "city-gardens": {
    "image": "/artcolor-preview/assets/project-scenes/city-gardens-light-r7.webp",
    "alt": "Визуализация Городских садов: деревянная скамья на белом бетонном обрамлении посадок",
    "items": [
      {
        "id": "bench",
        "title": "Скамья на бетонном обрамлении",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-043.webp",
        "description": "Деревянный настил со спинкой на бетонном обрамлении посадок. В каталоге показана похожая скамья «Багдад». Исполнение уточним по проекту.",
        "href": "/artcolor-preview/catalog/benches/",
        "linkLabel": "Посмотреть скамьи",
        "points": [
          {
            "x": 43,
            "y": 56
          }
        ],
        "photoAlt": "Скамья «Багдад 2000» с настилом и спинкой. Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      }
    ]
  },
  "bunin": {
    "image": "/artcolor-preview/assets/project-scenes/bunin-updated-r8.webp",
    "alt": "Визуализация ЖК Бунин: прямоугольная пергола, длинная скамья, урна и велопарковка на фоне кирпичных фасадов",
    "items": [
      {
        "id": "pergola",
        "title": "Пергола со скамьёй",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-172.webp",
        "description": "Реечный навес с ламельной стенкой и встроенной скамьёй. В каталоге показана похожая пергола «Гамма». Исполнение уточним по проекту.",
        "href": "/artcolor-preview/catalog/pergolas/",
        "linkLabel": "Посмотреть перголы",
        "points": [
          {
            "x": 60,
            "y": 31
          }
        ],
        "photoAlt": "Пергола «Гамма». Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      },
      {
        "id": "bin",
        "title": "Урна с деревянной вставкой",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-090.webp",
        "description": "Прямоугольный корпус с металлическими боковинами и деревянной вставкой. В каталоге подобрана похожая модель.",
        "href": "/artcolor-preview/product/ac-090/",
        "linkLabel": "Похожая модель «Город»",
        "points": [
          {
            "x": 75,
            "y": 56
          }
        ],
        "photoAlt": "Урна «Город» С деревом. Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      },
      {
        "id": "benches",
        "title": "Скамья с частичной спинкой",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-009.webp",
        "description": "Длинная скамья с частичной спинкой на металлических опорах. В каталоге показана похожая скамья «Новый город». Исполнение уточним по проекту.",
        "href": "/artcolor-preview/catalog/benches/",
        "linkLabel": "Посмотреть скамьи",
        "points": [
          {
            "x": 46,
            "y": 65
          }
        ],
        "photoAlt": "Скамейка «Новый город» со спинкой. Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      },
      {
        "id": "bikes",
        "title": "Велопарковка из пяти стоек",
        "photo": "/artcolor-preview/assets/catalog-studio/ac-198.webp",
        "description": "Велопарковка из пяти стоек на общей базе. Ссылка ведёт к похожей отдельной стойке, а не ко всему комплекту.",
        "href": "/artcolor-preview/product/ac-198/",
        "linkLabel": "Похожая стойка «Воздух»",
        "points": [
          {
            "x": 23,
            "y": 52
          }
        ],
        "photoAlt": "Велопарковка «Воздух». Студийное изображение из каталога",
        "photoLabel": "Похожая модель из каталога",
        "photoFit": "contain"
      }
    ]
  }
};
