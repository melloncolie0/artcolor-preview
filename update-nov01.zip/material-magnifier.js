const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
const zoom=2.5;

document.querySelectorAll('[data-material-magnifier]').forEach(stage=>{
  const photo=stage.querySelector('img');
  const trigger=stage.querySelector('[data-inspect-trigger]');
  const lens=stage.querySelector('[data-inspect-lens]');
  const hint=stage.querySelector('[data-inspect-hint]');
  if(!photo||!trigger||!lens||!hint)return;
  let hovered=false,pinned=false,frame=0,ready=false;
  const point={x:.5,y:.5};

  function draw(){
    frame=0;
    const active=ready&&(hovered||pinned);
    stage.dataset.inspectActive=String(active);
    trigger.setAttribute('aria-pressed',String(pinned));
    trigger.setAttribute('aria-label',pinned?'Убрать увеличение бетона':'Рассмотреть фактуру бетона');
    hint.textContent=pinned?'Убрать увеличение':active?'Приближение ×2,5':'Рассмотреть фактуру';
    if(!active)return;
    const {width,height}=photo.getBoundingClientRect();
    if(!width||!height)return;
    const diameter=Math.min(width-20,height-20,width<500?144:184);
    const radius=diameter/2;
    const x=point.x*width,y=point.y*height;
    const lensX=clamp(x,radius+8,width-radius-8);
    const lensY=clamp(y,radius+8,height-radius-8);
    // The photo uses object-fit: cover. Include its crop in the zoom coordinates.
    const scale=Math.max(width/photo.naturalWidth,height/photo.naturalHeight);
    const imageWidth=photo.naturalWidth*scale,imageHeight=photo.naturalHeight*scale;
    const cropX=(width-imageWidth)/2,cropY=(height-imageHeight)/2;
    lens.style.width=lens.style.height=`${diameter}px`;
    lens.style.setProperty('--lens-x',`${lensX-radius}px`);
    lens.style.setProperty('--lens-y',`${lensY-radius}px`);
    const zoomedWidth=imageWidth*zoom,zoomedHeight=imageHeight*zoom;
    lens.style.backgroundSize=`${zoomedWidth}px ${zoomedHeight}px`;
    lens.style.backgroundPosition=`${clamp(radius-(x-cropX)*zoom,diameter-zoomedWidth,0)}px ${clamp(radius-(y-cropY)*zoom,diameter-zoomedHeight,0)}px`;
  }

  function update(){if(!frame)frame=requestAnimationFrame(draw);}
  function locate(event){
    const rect=photo.getBoundingClientRect();
    if(rect.width&&rect.height){
      point.x=clamp((event.clientX-rect.left)/rect.width,0,1);
      point.y=clamp((event.clientY-rect.top)/rect.height,0,1);
    }
  }
  function close(){hovered=pinned=false;update();}
  function prepare(){
    if(!photo.naturalWidth||!photo.naturalHeight)return;
    ready=true;
    lens.style.backgroundImage=`url(${JSON.stringify(photo.currentSrc||photo.src)})`;
    trigger.hidden=lens.hidden=false;
    update();
  }

  stage.addEventListener('pointerenter',event=>{
    if(event.pointerType!=='mouse'&&event.pointerType!=='pen')return;
    hovered=true;locate(event);update();
  });
  stage.addEventListener('pointermove',event=>{
    if(event.pointerType!=='mouse'&&event.pointerType!=='pen')return;
    hovered=true;locate(event);update();
  });
  stage.addEventListener('pointerleave',()=>{hovered=false;update();});
  trigger.addEventListener('click',event=>{
    if(event.detail>0)locate(event);
    pinned=!pinned;
    if(!pinned)hovered=false;
    update();
  });
  trigger.addEventListener('blur',close);
  trigger.addEventListener('keydown',event=>{
    if(event.ctrlKey||event.metaKey||event.altKey)return;
    const directions={ArrowLeft:[-.06,0],ArrowRight:[.06,0],ArrowUp:[0,-.06],ArrowDown:[0,.06]};
    const delta=directions[event.key];
    if(delta){
      event.preventDefault();pinned=true;
      point.x=clamp(point.x+delta[0],0,1);point.y=clamp(point.y+delta[1],0,1);update();
    }else if(event.key==='Escape'){event.preventDefault();close();}
  });
  document.addEventListener('pointerdown',event=>{if(!stage.contains(event.target))close();});
  window.addEventListener('scroll',()=>{if(hovered){hovered=false;update();}},{passive:true});
  if('ResizeObserver' in window)new ResizeObserver(update).observe(photo);
  else window.addEventListener('resize',update,{passive:true});
  photo.addEventListener('load',prepare);
  if(photo.complete)prepare();
});
