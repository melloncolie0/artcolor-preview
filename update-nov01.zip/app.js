import {productCard,icon,esc,familyOf} from '/artcolor-preview/views.mjs?v=plus-nov01-r1';
import {panelTransition,closeDialog} from './site-motion-r4.js';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const motionPreference=window.matchMedia('(prefers-reduced-motion: reduce)');
const heroVideo=$('[data-hero-video]');
if(heroVideo){
  heroVideo.muted=true;
  const syncHeroMotion=()=>{
    heroVideo.autoplay=!motionPreference.matches;
    if(motionPreference.matches)heroVideo.pause();
    else heroVideo.play().catch(()=>{});
  };
  syncHeroMotion();
  motionPreference.addEventListener('change',syncHeroMotion);
}
// A small arrival on the two editorial blocks; all content stays visible if motion is unavailable.
if('IntersectionObserver' in window&&!motionPreference.matches){
  const arrivals=new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
      if(!entry.isIntersecting)return;
      if(!motionPreference.matches)entry.target.animate(
        [{opacity:.6,transform:'translateY(16px)'},{opacity:1,transform:'translateY(0)'}],
        {duration:650,easing:'cubic-bezier(.2,.7,.2,1)'}
      );
      arrivals.unobserve(entry.target);
    });
  },{threshold:.12});
  $$('.material-teaser,.project-reels').forEach(element=>arrivals.observe(element));
}
const mafTerm=$('[data-maf-term]');
if(mafTerm){
  const trigger=mafTerm.querySelector('.maf-trigger'),tooltip=mafTerm.querySelector('[role="tooltip"]');
  let hovered=false,pinned=false,keyboardFocus=false;
  const show=()=>{const open=hovered||pinned||keyboardFocus;tooltip.hidden=!open;trigger.setAttribute('aria-expanded',String(open));};
  const close=()=>{hovered=pinned=keyboardFocus=false;show();};
  mafTerm.addEventListener('pointerenter',event=>{if(event.pointerType==='mouse'||event.pointerType==='pen'){hovered=true;show();}});
  mafTerm.addEventListener('pointerleave',()=>{hovered=false;show();});
  trigger.addEventListener('focus',()=>{keyboardFocus=trigger.matches(':focus-visible');show();});
  trigger.addEventListener('blur',()=>{keyboardFocus=pinned=false;show();});
  trigger.addEventListener('click',()=>{pinned=!pinned;show();});
  document.addEventListener('pointerdown',event=>{if(!mafTerm.contains(event.target))close();});
  document.addEventListener('keydown',event=>{if(event.key==='Escape')close();});
}
const readSelection=()=>{try{const data=JSON.parse(localStorage.getItem('artcolor-selection-v1')||'[]');return Array.isArray(data)?data.filter(x=>typeof x.id==='string'&&Number.isFinite(x.qty)&&x.qty>0).map(x=>({id:x.id,qty:Math.min(999,Math.floor(x.qty))})):[];}catch{return [];}};
let selection=readSelection(),D;
let requestContextUpdater=null,requestSearch=null;
function saveSelection(){try{localStorage.setItem('artcolor-selection-v1',JSON.stringify(selection));}catch{toast('Подборка доступна только до закрытия страницы. Браузер не разрешает сохранение.');}updateSelection();}
let toastTimer;
function toast(text){const t=$('#toast');t.textContent=text;t.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.hidden=true,3500);}
function updateSelection(){const count=selection.length;$$('.selection-count').forEach(e=>{e.textContent=count;e.hidden=!count;});$$('[data-add]').forEach(e=>{const has=selection.some(x=>x.id===e.dataset.add);e.dataset.added=has;e.setAttribute('aria-pressed',has?'true':'false');if(e.classList.contains('button'))e.querySelector('span').textContent=has?'В подборке':'В подборку';});}
const menu=$('.menu-toggle'),mobileNavigation=$('#mobile-menu');
let menuAnimation;
function setMenuOpen(open,animate=true){
  if(!menu||!mobileNavigation)return;
  const wasVisible=!mobileNavigation.hidden;
  const opacity=wasVisible?getComputedStyle(mobileNavigation).opacity:'0';
  const transform=wasVisible?getComputedStyle(mobileNavigation).transform:'translateY(-8px)';
  menuAnimation?.cancel();
  menu.setAttribute('aria-expanded',String(open));
  menu.setAttribute('aria-label',open?'Закрыть меню':'Открыть меню');
  mobileNavigation.inert=!open;
  if(!animate||motionPreference.matches||!mobileNavigation.animate){mobileNavigation.hidden=!open;return;}
  if(!open&&!wasVisible)return;
  mobileNavigation.hidden=false;
  menuAnimation=mobileNavigation.animate(
    [{opacity,transform},{opacity:open?1:0,transform:open?'translateY(0)':'translateY(-8px)'}],
    {duration:open?220:150,easing:'cubic-bezier(.22,1,.36,1)'}
  );
  menuAnimation.onfinish=()=>{mobileNavigation.hidden=menu.getAttribute('aria-expanded')!=='true';menuAnimation=null;};
}
if(menu)menu.addEventListener('click',()=>setMenuOpen(menu.getAttribute('aria-expanded')!=='true'));
document.addEventListener('pointerdown',e=>{if(menu?.getAttribute('aria-expanded')==='true'&&!mobileNavigation.contains(e.target)&&!menu.contains(e.target))setMenuOpen(false);});
window.matchMedia('(min-width:1001px)').addEventListener('change',e=>{if(e.matches)setMenuOpen(false,false);});
$('#mobile-menu')?.addEventListener('click',e=>{if(e.target.closest('a')&&menu?.getAttribute('aria-expanded')==='true')menu.click();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&menu?.getAttribute('aria-expanded')==='true'){menu.click();menu.focus();}});
document.addEventListener('click',e=>{const add=e.target.closest('[data-add]');if(add){const id=add.dataset.add;if(!D?.products.some(p=>p.id===id))return;const old=selection.find(p=>p.id===id);if(old){toast('Изделие уже в подборке. Количество можно изменить в разделе «Моя подборка».');}else{selection.push({id,qty:1});saveSelection();toast('Изделие добавлено в подборку');}}});
const dialog=$('#image-dialog');
document.addEventListener('click',e=>{
  const open=e.target.closest('[data-lightbox]');if(!open)return;
  const photo=dialog.querySelector('img'),frame=dialog.querySelector('.dialog-photo-frame');
  let crop;try{crop=JSON.parse(open.dataset.photoCrop||'null');}catch{}
  const cropped=crop&&['x','y','w','h','ratio'].every(k=>Number.isFinite(crop[k]))&&crop.w>0&&crop.h>0&&crop.ratio>0&&crop.x>=0&&crop.y>=0&&crop.x+crop.w<=100&&crop.y+crop.h<=100;
  dialog.classList.toggle('is-cropped',!!cropped);frame.classList.toggle('is-cropped',!!cropped);
  if(cropped){frame.style.setProperty('--crop-aspect',String(crop.ratio*crop.w/crop.h));photo.style.cssText=`width:${10000/crop.w}%;height:${10000/crop.h}%;left:${-100*crop.x/crop.w}%;top:${-100*crop.y/crop.h}%;`;}else{frame.removeAttribute('style');photo.removeAttribute('style');}
  const nativeWidth=Number(open.dataset.nativeWidth),nativeHeight=Number(open.dataset.nativeHeight);
  const nativeSize=!cropped&&nativeWidth>0&&nativeHeight>0;
  dialog.classList.toggle('is-native-size',nativeSize);
  if(nativeSize){dialog.style.setProperty('--native-dialog-width',(nativeWidth+48)+'px');dialog.style.setProperty('--native-image-height',nativeHeight+'px');}
  else{dialog.style.removeProperty('--native-dialog-width');dialog.style.removeProperty('--native-image-height');}
  photo.src=open.dataset.lightbox;photo.alt=open.dataset.alt||'';dialog.showModal();
});
dialog?.querySelector('.dialog-close').addEventListener('click',()=>closeDialog(dialog));dialog?.addEventListener('click',e=>{if(e.target===dialog)closeDialog(dialog);});
$$('[data-product-image]').forEach(b=>b.addEventListener('click',()=>{$('.product-primary>img').src=b.dataset.productImage;$('.product-primary [data-lightbox]').dataset.lightbox=b.dataset.productImage;$$('[data-product-image]').forEach(x=>x.classList.toggle('selected',x===b));}));
const tabs=$$('[data-material-tab]');function activateTab(b){tabs.forEach(x=>{const active=x===b;x.setAttribute('aria-selected',String(active));x.tabIndex=active?0:-1;$('#panel-'+x.dataset.materialTab).hidden=!active;});}tabs.forEach((b,i)=>{b.addEventListener('click',()=>activateTab(b));b.addEventListener('keydown',e=>{let n;if(e.key==='ArrowRight')n=(i+1)%tabs.length;else if(e.key==='ArrowLeft')n=(i+tabs.length-1)%tabs.length;else if(e.key==='Home')n=0;else if(e.key==='End')n=tabs.length-1;if(n!==undefined){e.preventDefault();activateTab(tabs[n]);tabs[n].focus();}});});
function initCatalog(){const search=$('#catalog-search');if(!search)return;const params=new URLSearchParams(location.search),result=$('#product-results'),directory=$('#category-directory'),mat=$('#material-filter');let shown=12;const category=result.dataset.category,series=result.dataset.series;search.value=params.get('q')||'';if(mat)mat.value=params.get('material')||'';let material=params.get('material')||'';
function draw(sync=true){const q=search.value.trim().toLocaleLowerCase('ru'),m=mat?.value||material;const active=!!category||!!q||!!m;result.hidden=!active;if(directory)directory.hidden=active;const products=D.products.filter(p=>(!category||p.category===category)&&(!series||familyOf(p)===series)&&(!m||p.materials.includes(m))&&(!q||(p.name+' '+p.sku+' '+p.sourceName).toLocaleLowerCase('ru').includes(q)||p.sku.replace(/\s+/g,'').toLocaleLowerCase('ru').includes(q.replace(/\s+/g,''))));$('#product-grid').innerHTML=products.slice(0,shown).map(productCard).join('');$('#result-count').textContent=`Найдено изделий ${products.length}`;$('#empty-products').hidden=products.length>0;$('#load-more').hidden=products.length<=shown;$('#reset-filters').hidden=!q&&!m;updateSelection();if(sync){const url=new URL(location.href);q?url.searchParams.set('q',search.value.trim()):url.searchParams.delete('q');m?url.searchParams.set('material',m):url.searchParams.delete('material');history.replaceState(null,'',url);}}
search.addEventListener('input',()=>{shown=12;draw();});mat?.addEventListener('change',()=>{shown=12;material='';draw();});$('#load-more').addEventListener('click',()=>{shown+=12;draw(false);});$('#reset-filters').addEventListener('click',()=>{search.value='';material='';if(mat)mat.value='';shown=12;draw();search.focus();});draw(false);}
function initSelection(){const items=$('#selection-items');if(!items)return;function render(){const valid=selection.map(s=>({...s,p:D.products.find(p=>p.id===s.id)})).filter(s=>s.p);$('#selection-summary').hidden=!valid.length;if(!valid.length){items.innerHTML='<div class="empty-state"><h2>В подборке пока нет изделий</h2><p>Добавляйте модели из каталога. Здесь можно изменить количество и подготовить заявку на весь комплект.</p><a class="button button--dark" href="/artcolor-preview/catalog/">Открыть каталог</a></div>';return;}items.innerHTML=valid.map(s=>`<article class="selection-item"><a href="/artcolor-preview/product/${s.id}/"><img src="${s.p.image}" alt="${esc(s.p.name)}"></a><div><span class="small muted">${esc(s.p.sku)}</span><h2><a href="/artcolor-preview/product/${s.id}/">${esc(s.p.name)}</a></h2><p class="small">${esc(s.p.materialText)}</p><div class="quantity-control"><button data-qty-minus="${s.id}" aria-label="Уменьшить количество ${esc(s.p.name)}">−</button><input data-qty="${s.id}" type="number" min="1" max="999" value="${s.qty}" aria-label="Количество ${esc(s.p.name)}"><button data-qty-plus="${s.id}" aria-label="Увеличить количество ${esc(s.p.name)}">+</button><span class="small muted">шт.</span></div></div><button class="remove-item" data-remove="${s.id}" aria-label="Удалить ${esc(s.p.name)}">${icon('close')}</button></article>`).join('');$('#selection-total').textContent=`Позиций ${valid.length}, всего изделий ${valid.reduce((a,b)=>a+b.qty,0)}`;}
items.addEventListener('click',e=>{const remove=e.target.closest('[data-remove]'),minus=e.target.closest('[data-qty-minus]'),plus=e.target.closest('[data-qty-plus]');if(remove){selection=selection.filter(x=>x.id!==remove.dataset.remove);saveSelection();render();}else if(minus||plus){const item=selection.find(x=>x.id===(minus?.dataset.qtyMinus||plus?.dataset.qtyPlus));item.qty=Math.max(1,Math.min(999,item.qty+(plus?1:-1)));saveSelection();render();}});items.addEventListener('change',e=>{if(e.target.matches('[data-qty]')){const item=selection.find(x=>x.id===e.target.dataset.qty);item.qty=Math.max(1,Math.min(999,parseInt(e.target.value)||1));saveSelection();render();}});$('#clear-selection').addEventListener('click',()=>{selection=[];saveSelection();render();});render();}
function initRequest(){const form=$('#request-form');if(!form)return;const currentProducts=[];let context='';
function setContext(search){const params=new URLSearchParams(search),p=D.products.find(p=>p.id===params.get('product'));const chosen=p?[{id:p.id,qty:1}]:params.get('mode')==='selection'?selection:[];currentProducts.splice(0,currentProducts.length,...chosen.map(s=>({...s,p:D.products.find(p=>p.id===s.id)})).filter(s=>s.p));context=params.get('project')||params.get('category')||'';const box=$('#request-context');box.hidden=!currentProducts.length&&!context;box.innerHTML=currentProducts.length||context?`<h2>${currentProducts.length?'Состав заявки':'Задача'}</h2>${currentProducts.map(s=>`<p>${esc(s.p.name)} (${esc(s.p.sku)}), ${s.qty} шт.</p>`).join('')}${context?`<p>${esc(context)}</p>`:''}`:'';form.hidden=false;$('#request-success').hidden=true;}
requestContextUpdater=setContext;setContext(requestSearch??location.search);
let files=[],prepared;const input=$('#request-files'),list=$('#file-list'),err=$('#form-error');function error(text){err.textContent=text;err.hidden=!text;}function renderFiles(){list.innerHTML=files.map((f,i)=>`<div class="file-item"><span>${esc(f.name)}</span><span class="muted">${(f.size/1024/1024).toFixed(2)} МБ</span><button type="button" data-remove-file="${i}" aria-label="Удалить файл ${esc(f.name)}">${icon('close')}</button></div>`).join('');}function addFiles(incoming){const next=[...files];for(const f of incoming){if(!/\.(pdf|docx?|xlsx?|csv|png|jpe?g|webp|dwg|dxf|zip|rar|7z)$/i.test(f.name)){error('Этот формат не поддерживается. Прикрепите документ, изображение, чертёж или архив.');return;}if(!next.some(x=>x.name===f.name&&x.size===f.size&&x.lastModified===f.lastModified))next.push(f);}if(next.length>5){error('Можно прикрепить не более 5 файлов. Удалите лишние или объедините их в архив.');return;}if(next.reduce((s,f)=>s+f.size,0)>20*1024*1024){error('Общий размер файлов больше 20 МБ. Уменьшите файлы или приложите архив.');return;}files=next;error('');renderFiles();}input.addEventListener('change',()=>{addFiles([...input.files]);input.value='';});list.addEventListener('click',e=>{const b=e.target.closest('[data-remove-file]');if(b){files.splice(Number(b.dataset.removeFile),1);renderFiles();error('');}});const drop=$('#file-drop');drop.addEventListener('dragover',e=>{e.preventDefault();drop.classList.add('dragging');});drop.addEventListener('dragleave',()=>drop.classList.remove('dragging'));drop.addEventListener('drop',e=>{e.preventDefault();drop.classList.remove('dragging');addFiles([...e.dataTransfer.files]);});
form.addEventListener('submit',e=>{e.preventDefault();error('');const fd=new FormData(form),phone=String(fd.get('phone')).replace(/\D/g,'');if(phone.length<10||phone.length>15){error('Укажите телефон полностью, с кодом города или оператора.');form.elements.phone.focus();return;}if(!String(fd.get('name')).trim()){error('Укажите, как к вам обращаться.');form.elements.name.focus();return;}prepared={name:String(fd.get('name')).trim(),company:String(fd.get('company')).trim(),phone:String(fd.get('phone')).trim(),email:String(fd.get('email')).trim(),message:String(fd.get('message')).trim(),context,products:currentProducts.map(s=>({id:s.id,sku:s.p.sku,name:s.p.name,quantity:s.qty})),files:files.map(f=>({name:f.name,size:f.size})),createdAt:new Date().toISOString(),status:'prepared_not_sent'};$('#request-review').innerHTML=`<p>${esc(prepared.name)}${prepared.company?', '+esc(prepared.company):''}</p><p>${esc(prepared.phone)}${prepared.email?', '+esc(prepared.email):''}</p>${prepared.message?`<p>${esc(prepared.message)}</p>`:''}${prepared.products.map(x=>`<p>${esc(x.name)}, ${x.quantity} шт.</p>`).join('')}<p>Файлов ${files.length}</p>`;form.hidden=true;$('#request-success').hidden=false;$('#request-success h2').tabIndex=-1;$('#request-success h2').focus();});$('#edit-request').addEventListener('click',()=>{form.hidden=false;$('#request-success').hidden=true;form.elements.name.focus();});$('#download-request').addEventListener('click',async()=>{if(!prepared)return;const b=$('#download-request');b.disabled=true;try{const text=`ЗАЯВКА АРТКОЛОР36\nПодготовлена в версии сайта для согласования. Менеджеру не отправлена.\n\nИмя: ${prepared.name}\nКомпания: ${prepared.company}\nТелефон: ${prepared.phone}\nПочта: ${prepared.email}\n\nЗадача: ${prepared.context}\n${prepared.message}\n\nИЗДЕЛИЯ\n${prepared.products.map(p=>`${p.sku} | ${p.name} | ${p.quantity} шт.`).join('\n')}\n\nПРИЛОЖЕНИЯ\n${files.map(f=>f.name).join('\n')}`;const entries=[{name:'Заявка.txt',bytes:new TextEncoder().encode(text)},{name:'request.json',bytes:new TextEncoder().encode(JSON.stringify(prepared,null,2))}];for(let i=0;i<files.length;i++)entries.push({name:`Файлы/${i+1}-${files[i].name.replace(/[\\/]/g,'_')}`,bytes:new Uint8Array(await files[i].arrayBuffer())});const blob=zip(entries),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Artcolor-заявка.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);toast('Архив заявки готов. Отправка менеджеру не выполнялась.');}catch{toast('Не удалось собрать архив. Попробуйте ещё раз или уменьшите размер файлов.');}finally{b.disabled=false;}});}
// ZIP store format with UTF-8 names. Files stay in the browser throughout.
function zip(entries){const table=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;table[n]=c;}const chunks=[],central=[];let offset=0;for(const e of entries){const name=new TextEncoder().encode(e.name);let crc=0xffffffff;for(const b of e.bytes)crc=table[(crc^b)&255]^(crc>>>8);crc=(crc^0xffffffff)>>>0;const h=new Uint8Array(30+name.length),v=new DataView(h.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x0800,true);v.setUint32(14,crc,true);v.setUint32(18,e.bytes.length,true);v.setUint32(22,e.bytes.length,true);v.setUint16(26,name.length,true);h.set(name,30);chunks.push(h,e.bytes);const c=new Uint8Array(46+name.length),cv=new DataView(c.buffer);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x0800,true);cv.setUint32(16,crc,true);cv.setUint32(20,e.bytes.length,true);cv.setUint32(24,e.bytes.length,true);cv.setUint16(28,name.length,true);cv.setUint32(42,offset,true);c.set(name,46);central.push(c);offset+=h.length+e.bytes.length;}const size=central.reduce((n,b)=>n+b.length,0),end=new Uint8Array(22),ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,entries.length,true);ev.setUint16(10,entries.length,true);ev.setUint32(12,size,true);ev.setUint32(16,offset,true);return new Blob([...chunks,...central,end],{type:'application/zip'});}

const requestDialog=$('#request-dialog');
if(requestDialog){document.addEventListener('click',e=>{const a=e.target.closest('a[data-open-request]');if(!a||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||e.button>0)return;e.preventDefault();requestSearch=new URL(a.href,location.href).search;requestContextUpdater?.(requestSearch);if(menu?.getAttribute('aria-expanded')==='true')menu.click();requestDialog.showModal();document.documentElement.classList.add('request-is-open');requestDialog.scrollTop=0;requestDialog.querySelector('input[name="name"]').focus({preventScroll:true});});requestDialog.querySelector('[data-close-request]').addEventListener('click',()=>closeDialog(requestDialog));requestDialog.addEventListener('click',e=>{if(e.target===requestDialog)closeDialog(requestDialog);});requestDialog.addEventListener('close',()=>document.documentElement.classList.remove('request-is-open'));}

function initProjectExplorer(){
  $$('[data-project-explorer]').forEach(explorer=>{
    const controls=[...explorer.querySelectorAll('[data-scene-select]')];
    const panels=[...explorer.querySelectorAll('.scene-item')];
    const show=panelTransition(explorer.querySelector('.scene-item-list'),panels);
    function select(id){
      if(!panels.some(panel=>panel.id==='scene-item-'+id))return;
      controls.forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.sceneSelect===id)));
      show(panels.find(panel=>panel.id==='scene-item-'+id));
    }
    controls.forEach(button=>{
      button.addEventListener('click',()=>select(button.dataset.sceneSelect));
      button.addEventListener('keydown',event=>{
        if(event.ctrlKey||event.metaKey||event.altKey)return;
        const group=[...button.closest('[role="group"]').querySelectorAll('[data-scene-select]')];
        const index=group.indexOf(button);let next;
        if(event.key==='ArrowRight'||event.key==='ArrowDown')next=(index+1)%group.length;
        else if(event.key==='ArrowLeft'||event.key==='ArrowUp')next=(index+group.length-1)%group.length;
        else if(event.key==='Home')next=0;
        else if(event.key==='End')next=group.length-1;
        if(next!==undefined){event.preventDefault();select(group[next].dataset.sceneSelect);group[next].focus();}
      });
    });
  });
}
initProjectExplorer();
updateSelection();fetch('/artcolor-preview/data.json?v=planters-nov01-r4').then(r=>{if(!r.ok)throw Error();return r.json();}).then(data=>{D=data;selection=selection.filter(s=>D.products.some(p=>p.id===s.id));updateSelection();initCatalog();initSelection();initRequest();}).catch(()=>toast('Не удалось загрузить данные. Обновите страницу или позвоните нам.'));

$('.series-select')?.addEventListener('change',e=>location.assign(e.target.value));

function initProductionStory(){
 document.querySelectorAll('[data-production-story]').forEach(root=>{
  const controls=[...root.querySelectorAll('[data-production-select]')],panels=[...root.querySelectorAll('[data-production-panel]')];
  const pointer=window.matchMedia('(hover:hover) and (pointer:fine)');
  let active=controls.find(button=>button.getAttribute('aria-selected')==='true')?.dataset.productionSelect,timer,pending;
  const cancelPreview=()=>{clearTimeout(timer);pending=null;};
  const select=key=>{
   cancelPreview();if(key===active)return;active=key;
   controls.forEach(button=>{const selected=button.dataset.productionSelect===key;button.setAttribute('aria-selected',String(selected));button.tabIndex=selected?0:-1;});
   panels.forEach(panel=>{const selected=panel.dataset.productionPanel===key;panel.classList.toggle('is-active',selected);panel.setAttribute('aria-hidden',String(!selected));panel.inert=!selected;panel.tabIndex=selected?0:-1;});
  };
  controls.forEach((button,index)=>{
   // Actual pointer motion activates a preview. Layout movement under a still pointer does not.
   button.addEventListener('pointermove',event=>{
    const key=button.dataset.productionSelect;if(!pointer.matches||event.pointerType==='touch'||active===key||pending===key)return;
    cancelPreview();pending=key;timer=setTimeout(()=>select(key),140);
   });
   button.addEventListener('pointerleave',cancelPreview);
   button.addEventListener('click',()=>select(button.dataset.productionSelect));
   button.addEventListener('keydown',event=>{
    if(event.ctrlKey||event.altKey||event.metaKey)return;
    let next;if(event.key==='ArrowDown'||event.key==='ArrowRight')next=(index+1)%controls.length;
    else if(event.key==='ArrowUp'||event.key==='ArrowLeft')next=(index+controls.length-1)%controls.length;
    else if(event.key==='Home')next=0;else if(event.key==='End')next=controls.length-1;
    if(next!==undefined){event.preventDefault();select(controls[next].dataset.productionSelect);controls[next].focus();}
   });
  });
 });
}
initProductionStory();

function initProjectGallery(){
 document.querySelectorAll('.project-gallery').forEach(gallery=>{
  const cards=[...gallery.querySelectorAll('button')];let frame;
  const ratio=card=>Number(card.dataset.photoRatio)||1.5;
  const layout=()=>{
   frame=0;const width=gallery.clientWidth;if(!width||!cards.length)return;
   const narrow=width<620,gap=narrow?14:26;
   const weights=narrow?[1.04,.96]:[.97,1.08,.95];
   const offsets=narrow?[0,38]:[0,62,126];
   const unit=(width-gap*(weights.length-1))/weights.reduce((sum,w)=>sum+w,0);
   const widths=weights.map(w=>unit*w),left=[];let nextLeft=0;
   widths.forEach(w=>{left.push(nextLeft);nextLeft+=w+gap;});
   const heights=[...offsets];
   const portrait=cards.slice(1).filter(card=>ratio(card)<1).sort((a,b)=>ratio(a)-ratio(b))[0];
   const order=portrait?[cards[0],portrait,...cards.slice(1).filter(card=>card!==portrait)]:cards;
   order.forEach((card,index)=>{
    const column=index<weights.length?index:heights.indexOf(Math.min(...heights));
    const height=widths[column]/ratio(card);
    card.style.setProperty('--gallery-x',left[column]+'px');card.style.setProperty('--gallery-y',heights[column]+'px');card.style.setProperty('--gallery-width',widths[column]+'px');
    heights[column]+=height+gap;
   });
   gallery.style.height=Math.max(...heights)-gap+'px';gallery.dataset.galleryReady='true';
  };
  const schedule=()=>{if(!frame)frame=requestAnimationFrame(layout);};
  cards.forEach(card=>card.querySelector('img')?.addEventListener('load',schedule));
  if('ResizeObserver' in window){const observer=new ResizeObserver(schedule);observer.observe(gallery);}
  else window.addEventListener('resize',schedule,{passive:true});
  schedule();
 });
}
initProjectGallery();
