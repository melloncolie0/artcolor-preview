// Native details remain available when scripts or motion are disabled.
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

for (const detail of document.querySelectorAll('.concrete-info')) {
  const summary = detail.querySelector('summary');
  const body = detail.querySelector('.concrete-info-body');
  if (!summary || !body || typeof body.animate !== 'function') continue;
  const reveal = document.createElement('div');
  reveal.className = 'concrete-info-reveal';
  body.before(reveal);
  reveal.append(body);
  detail.dataset.animatedDetails = 'true';
  let expanded = detail.open;
  let animation;

  const sync = () => {
    summary.setAttribute('aria-expanded', String(expanded));
    reveal.inert = !expanded;
    reveal.setAttribute('aria-hidden', String(!expanded));
  };
  const settle = () => {
    detail.open = expanded;
    if (animation) {
      animation.onfinish = null;
      animation.cancel();
      animation = undefined;
    }
  };
  sync();

  summary.addEventListener('click', event => {
    event.preventDefault();
    // Read the current rendered frame before cancelling, so reversals do not jump.
    const from = detail.open ? reveal.getBoundingClientRect().height : 0;
    const opacity = detail.open ? Number(getComputedStyle(reveal).opacity) : 0;
    if (animation) { animation.onfinish = null; animation.cancel(); }
    expanded = !expanded;
    sync();
    if (reducedMotion.matches || event.detail === 0) { settle(); return; }
    detail.open = true;
    const to = expanded ? reveal.scrollHeight : 0;
    animation = reveal.animate(
      [{ height: `${from}px`, opacity }, { height: `${to}px`, opacity: expanded ? 1 : 0 }],
      { duration: expanded ? 280 : 240, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'both' }
    );
    animation.onfinish = settle;
  });
  reducedMotion.addEventListener('change', () => { if (reducedMotion.matches) settle(); });
}
