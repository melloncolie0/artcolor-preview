import {initialMaterialState,nextMaterialState} from './materials-state.mjs?v=materials-r6';
import {panelTransition} from './site-motion-r4.js';

let sceneModule;
const motion=window.matchMedia('(prefers-reduced-motion: reduce)');
const hover=window.matchMedia('(hover: hover) and (pointer: fine)');

for(const root of document.querySelectorAll('[data-material-explorer]')){
  const stage=root.querySelector('[data-model-stage]');
  const status=root.querySelector('[data-model-status]');
  const toggle=root.querySelector('[data-model-toggle]');
  const reset=root.querySelector('[data-model-reset]');
  const materialButtons=[...root.querySelectorAll('[data-model-material]')];
  const panels=[...root.querySelectorAll('[data-model-panel]')];
  const descriptions=root.querySelector('.material-descriptions');
  let state=initialMaterialState(),scene,loading=false,disposed=false,leaveTimer,previewTimer;
  const showDescription=panelTransition(descriptions,panels,{stableHeight:true});
  const showPanel=material=>showDescription(panels.find(panel=>panel.dataset.modelPanel===material));

  const draw=()=>{
    root.dataset.expanded=String(state.expanded);
    root.dataset.material=state.material||'all';
    root.dataset.part=state.part||'none';
    toggle.disabled=!state.part;
    toggle.closest('.material-model-actions').hidden=!state.expanded;
    materialButtons.forEach(button=>button.setAttribute('aria-pressed',String(state.material===button.dataset.modelMaterial)));
    showPanel(state.material||'all');
    reset.hidden=!state.expanded;
    scene?.setState(state,motion.matches);
  };
  const act=action=>{const next=nextMaterialState(state,action);if(next!==state){state=next;draw();}};
  const preview=action=>{clearTimeout(previewTimer);previewTimer=setTimeout(()=>act(action),action.part||action.material?90:220);};
  const choose=action=>{clearTimeout(previewTimer);clearTimeout(leaveTimer);act(action);};

  async function load(){
    if(loading||scene||disposed)return;
    loading=true;root.dataset.modelState='loading';status.hidden=false;status.textContent='Загружаем модель';
    try{
      sceneModule??=import('./materials-scene-r1.js?v=materials-r6');
      const {createMaterialScene}=await sceneModule;
      if(disposed)return;
      scene=await createMaterialScene(stage,{
        source:root.dataset.modelSource,
        onProgress:progress=>{if(!disposed)status.textContent=progress?'Загружаем модель, '+progress+'%':'Загружаем модель';},
        onPreview:part=>preview({type:'preview',part}),
        onSelect:part=>choose({type:'select',part}),
        onReset:()=>choose({type:'reset'})
      });
      if(disposed){scene.dispose();return;}
      root.dataset.modelState='ready';root.dataset.modelTriangles=String(scene.triangles);root.dataset.modelParts=String(scene.parts);
      status.hidden=true;draw();
    }catch(error){
      root.dataset.modelState='fallback';status.hidden=false;status.textContent='3D-модель пока недоступна. Выберите материал, чтобы узнать о его обработке';
      console.warn('Material model could not be displayed.',error);
    }finally{loading=false;}
  }

  root.addEventListener('pointerenter',()=>clearTimeout(leaveTimer));
  stage.addEventListener('pointerenter',event=>{if(hover.matches&&event.pointerType!=='touch')load();});
  stage.addEventListener('pointerleave',()=>preview({type:'leave'}));
  root.addEventListener('pointerleave',()=>{clearTimeout(leaveTimer);leaveTimer=setTimeout(()=>{clearTimeout(previewTimer);act({type:'leave'});},220);});
  const resetSelection=()=>{
    choose({type:'reset'});scene?.resetView(motion.matches);
    (stage.querySelector('canvas')||root.querySelector('.material-pickers')).focus({preventScroll:true});
  };
  toggle.addEventListener('click',resetSelection);
  reset.addEventListener('click',resetSelection);
  materialButtons.forEach(button=>{
    const material=button.dataset.modelMaterial;
    button.addEventListener('pointerenter',event=>{if(hover.matches&&event.pointerType!=='touch')preview({type:'preview',material});});
    button.addEventListener('pointerleave',()=>preview({type:'leave'}));
    button.addEventListener('focus',()=>{if(button.matches(':focus-visible'))choose({type:'preview',material});});
    button.addEventListener('blur',()=>preview({type:'leave'}));
    button.addEventListener('click',()=>{choose({type:'select',material});load();});
  });
  root.addEventListener('keydown',event=>{if(event.key==='Escape'){choose({type:'reset'});scene?.resetView(motion.matches);}});
  if('IntersectionObserver' in window){
    const loader=new IntersectionObserver(entries=>{if(entries.some(entry=>entry.isIntersecting)){load();loader.disconnect();}},{rootMargin:'450px 0px'});
    loader.observe(root);
  }else load();
  const visibility='IntersectionObserver' in window?new IntersectionObserver(entries=>scene?.setVisible(entries[0].isIntersecting),{threshold:.02}):null;
  visibility?.observe(stage);
  window.addEventListener('pagehide',()=>{disposed=true;clearTimeout(leaveTimer);clearTimeout(previewTimer);visibility?.disconnect();scene?.dispose();},{once:true});
  const requestedMaterial=new URL(location.href).searchParams.get('material');
  if(materialButtons.some(button=>button.dataset.modelMaterial===requestedMaterial)){
    state=nextMaterialState(state,{type:'select',material:requestedMaterial});
  }
  draw();
}
