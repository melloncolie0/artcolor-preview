const preference=window.matchMedia('(prefers-reduced-motion: reduce)');
const ease='cubic-bezier(.22,1,.36,1)';

// Keep native hidden/inert semantics outside the short overlap between two panels.
export function panelTransition(container,panels,{stableHeight=false}={}){
  let current=panels.find(panel=>!panel.hidden),running=[],revision=0;
  const clear=()=>{running.forEach(animation=>animation.cancel());running=[];};
  const reset=panel=>{panel.style.removeProperty('position');panel.style.removeProperty('inset');panel.style.removeProperty('width');};
  return next=>{
    if(!next||next===current)return;
    const previous=current,startHeight=container.getBoundingClientRect().height;
    const startOpacity=previous?getComputedStyle(previous).opacity:1;
    const ticket=++revision;clear();current=next;
    panels.forEach(panel=>{reset(panel);panel.hidden=panel!==next&&panel!==previous;panel.inert=panel!==next;panel.setAttribute('aria-hidden',String(panel!==next));});
    const duration=preference.matches?260:620;
    if(previous&&!stableHeight){previous.style.position='absolute';previous.style.inset='0 auto auto 0';previous.style.width='100%';}
    const endHeight=next.getBoundingClientRect().height;
    if(!stableHeight){
      container.style.height=startHeight+'px';container.style.overflow='hidden';
      running.push(container.animate([{height:startHeight+'px'},{height:endHeight+'px'}],{duration,easing:ease,fill:'both'}));
    }
    if(previous)running.push(previous.animate([{opacity:startOpacity},{opacity:0}],{duration:preference.matches?180:240,easing:'ease-out',fill:'both'}));
    const entry=next.animate([
      {opacity:0,transform:preference.matches?'none':'translateY(5px)'},
      {opacity:1,transform:'none'}
    ],{duration,easing:ease,fill:'both'});
    running.push(entry);
    entry.onfinish=()=>{
      if(ticket!==revision)return;
      panels.forEach(panel=>{panel.hidden=panel!==next;reset(panel);});
      container.style.removeProperty('height');container.style.removeProperty('overflow');clear();
    };
  };
}

export function closeDialog(dialog){
  if(!dialog?.open||dialog.dataset.closing==='true')return;
  dialog.dataset.closing='true';
  const animation=dialog.animate([
    {opacity:getComputedStyle(dialog).opacity,transform:getComputedStyle(dialog).transform},
    {opacity:0,transform:preference.matches?'none':'translateY(6px) scale(.995)'}
  ],{duration:preference.matches?150:260,easing:ease,fill:'both'});
  animation.onfinish=()=>{dialog.close();delete dialog.dataset.closing;animation.cancel();};
}

document.querySelectorAll('dialog').forEach(dialog=>{
  dialog.addEventListener('cancel',event=>{event.preventDefault();closeDialog(dialog);});
});

// Details stay usable without JavaScript. With it, closing also animates and reverses.
const accordions=new Map();
document.querySelectorAll('details.detail').forEach(detail=>{
  const summary=detail.querySelector(':scope > summary');if(!summary)return;
  const body=document.createElement('div');body.className='detail-body';
  [...detail.childNodes].filter(node=>node!==summary).forEach(node=>body.append(node));detail.append(body);
  const groupName=detail.getAttribute('name');
  if(groupName)detail.removeAttribute('name');
  let target=detail.open,animation;
  const controller={set(open){
    if(open===target)return;
    target=open;
    const height=detail.open?body.getBoundingClientRect().height:0;
    const opacity=detail.open?Number(getComputedStyle(body).opacity):0;
    if(animation){animation.onfinish=null;animation.cancel();}
    if(open)detail.open=true;
    summary.setAttribute('aria-expanded',String(open));
    const end=open?body.scrollHeight:0;
    animation=body.animate([{height:height+'px',opacity},{height:end+'px',opacity:open?1:0}],{
      duration:preference.matches?260:580,easing:ease,fill:'both'
    });
    animation.onfinish=()=>{detail.open=target;animation.cancel();animation=null;};
  }};
  if(groupName){if(!accordions.has(groupName))accordions.set(groupName,[]);accordions.get(groupName).push(controller);}
  summary.setAttribute('aria-expanded',String(target));
  summary.addEventListener('click',event=>{
    event.preventDefault();const open=!target;
    if(open&&groupName)accordions.get(groupName).forEach(other=>{if(other!==controller)other.set(false);});
    controller.set(open);
  });
});
