// Exact critically damped motion preserves speed when the target changes.
export function stepMaterialMotion(motion,target,deltaMs){
  const seconds=Math.max(0,Math.min(deltaMs,64))/1000,omega=9;
  const distance=motion.value-target,coefficient=motion.velocity+omega*distance,decay=Math.exp(-omega*seconds);
  motion.value=target+(distance+coefficient*seconds)*decay;
  motion.velocity=(motion.velocity-omega*coefficient*seconds)*decay;
  const moving=Math.abs(motion.value-target)>.0002||Math.abs(motion.velocity)>.002;
  if(!moving){motion.value=target;motion.velocity=0;}
  return moving;
}
