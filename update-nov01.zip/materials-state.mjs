export const MATERIAL_KEYS=['concrete','wood','metal'];
export const MATERIAL_PARTS={concrete:'concrete',wood:'wood_right',metal:'metal'};
export const PART_MATERIALS={concrete:'concrete',wood_left:'wood',wood_right:'wood',metal:'metal'};
export const initialMaterialState=()=>({expanded:false,material:null,part:null,pinned:false});
export function nextMaterialState(state,action){
  switch(action.type){
    case 'preview':
    case 'select':{
      const part=action.part||MATERIAL_PARTS[action.material];
      if(!part)return action.type==='preview'&&!state.pinned?initialMaterialState():state;
      const material=PART_MATERIALS[part];
      if(!material)return state;
      if(action.type==='select'&&state.pinned&&state.part===part)return initialMaterialState();
      return {expanded:true,material,part,pinned:action.type==='select'};
    }
    case 'leave':return state.pinned?state:initialMaterialState();
    case 'reset':return initialMaterialState();
    default:return state;
  }
}
