const escape = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const plus = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 4v16M4 12h16" stroke="currentColor" stroke-width="1.4"/></svg>';
const arrow = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6" stroke="currentColor" stroke-width="1.4"/></svg>';

export const materials = [
  {id:'concrete',summary:'Для опор и столешниц. Шлифуем поверхность и обрабатываем кромки.',name:'Архитектурный бетон',alt:'Светлый архитектурный бетон с мелкими порами и обработанной кромкой на нейтральном фоне',text:'Бетон задаёт геометрию изделия. Поверхность может оставаться выразительно фактурной или становиться более гладкой после обработки. Фактуру и финиш подбираем для конкретной модели.',process:'Последовательно шлифуем поверхность с водой, обрабатываем кромки и стыки. Цвет, фактуру и покрытие согласуем по образцу.',use:'Опоры скамеек, столешницы, вазоны и элементы благоустройства.'},
  {id:'wood',summary:'Для сидений и спинок. Шлифуем доску и покрываем террасным маслом.',name:'Дерево',alt:'Деревянная планка с естественным рисунком волокон и обработанной кромкой на нейтральном фоне',text:'Дерево используется в сиденьях, спинках и настилах. Рисунок волокон делает каждую поверхность немного разной. Породу, сечение и оттенок подбираем под изделие.',process:'Работаем с сухой доской. Шлифуем поверхность и обрабатываем террасным маслом. Повторную шлифовку и покрытие выполняем по выбранной технологии.',use:'Сиденья, спинки, столешницы, настилы и рейки пергол.'},
  {id:'metal',summary:'Для каркасов и навесов. Зачищаем сварные швы и готовим к порошковой окраске.',name:'Металл',alt:'Прямоугольный стальной профиль с матовым тёмным покрытием на нейтральном фоне',text:'Металл формирует каркас и опоры. Сечение профиля, способ соединения и крепления зависят от конструкции и условий установки.',process:'Свариваем детали, зачищаем швы и подготавливаем поверхность к порошковой окраске. Оттенок и покрытие согласуем для заказа.',use:'Каркасы мебели, опоры, навесы, ограждения и велопарковки.'}
];

function materialPhoto(m, className='') {
  const crop={concrete:{x:0,y:0,w:32.7808,h:100,ratio:3},wood:{x:33.6096,y:0,w:32.6888,h:100,ratio:3},metal:{x:67.1271,y:0,w:32.8729,h:100,ratio:3}}[m.id];
  const photo='/artcolor-preview/assets/material-details/material-macro-series-r1.webp';
  return `<button type="button" class="material-photo-button ${className} material-photo--${m.id}" data-lightbox="${photo}" data-photo-crop="${escape(JSON.stringify(crop))}" data-alt="${escape(m.alt)}" aria-label="Увеличить фотографию материала ${escape(m.name)}"><span class="material-photo-crop" style="--photo-width:${10000/crop.w}%;--photo-left:${-100*crop.x/crop.w}%"><img src="${photo}" width="2172" height="724" alt="${escape(m.alt)}" loading="lazy" decoding="async"></span><span class="material-photo-zoom" aria-hidden="true">${plus}</span></button>`;
}

export function materialsSpotlight() {
  return `<section id="materials" class="materials-spotlight wrap" aria-labelledby="materials-home-title"><div class="section-heading"><h2 id="materials-home-title">Материалы</h2><a class="text-link materials-about-link" href="/artcolor-preview/about/#materials">Обработка и применение<span class="round-link">${arrow}</span></a></div><div class="materials-preview-grid">${materials.map(m=>`<article id="material-${m.id}">${materialPhoto(m)}<h3><a class="material-description-link" href="/artcolor-preview/about/?material=${m.id}#materials" aria-label="${escape(m.name)}. Обработка и применение"><span>${m.id==='concrete'?'Бетон':m.name}</span>${arrow}</a></h3><p class="material-summary">${m.summary}</p></article>`).join('')}</div></section>`;
}

export function contactPhoneHref(phone) {return 'tel:' + String(phone ?? '').replace(/[^+\d]/g,'');}
export function contactEmail(c,className='') {return c.email?`<a class="contact-email ${className}" href="mailto:${escape(c.email)}">${escape(c.email)}</a>`:'';}

export function specificationRows(p) {
  const fields=p.specificationRows || p.specifications.map(s=>{
    const colon=s.indexOf(':');
    if(colon>=0)return {label:s.slice(0,colon),value:s.slice(colon+1).trim()};
    const match=s.match(/^(Длина|Ширина|Высота|Глубина|Диаметр|Вес|Тип крепления|Материалы)\s+(.+)$/i);
    return {label:match?.[1]||'Габариты',value:match?.[2]||s};
  });
  return fields.length ? fields.map(f=>`<div><dt>${escape(f.label)}</dt><dd>${escape(f.value)}</dd></div>`).join('') : '<div><dt>Характеристики</dt><dd>Уточним по вашему запросу</dd></div>';
}

export function dimensionDiagram(p) {
  const d=p.dimensionsMm;
  if(!d||!['Длина','Ширина','Высота'].every(k=>Number.isFinite(d[k])&&d[k]>0)) return '';
  const value=k=>escape(String(d[k]).replace('.',','))+' мм';
  const id='dim-'+p.id;
  return `<section class="product-dimensions" aria-labelledby="${id}-title"><div><h2 id="${id}-title">Габариты изделия</h2><p>Схема показывает общие размеры без масштаба. Рабочие чертежи и схему крепления уточним при расчёте.</p><a class="text-link" href="/artcolor-preview/request/?product=${p.id}">Запросить чертёж<span class="round-link">${arrow}</span></a></div><figure class="dimension-envelope"><svg viewBox="0 0 640 340" role="img" aria-label="Габариты ${escape(p.name)}. Длина ${value('Длина')}, ширина ${value('Ширина')}, высота ${value('Высота')}"><defs><marker id="${id}-arrow" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto-start-reverse"><path d="M7 1L1 4l6 3" fill="none" stroke="currentColor"/></marker></defs><g fill="none" stroke="currentColor" stroke-width="1.4"><rect x="95" y="60" width="330" height="65"/><rect x="95" y="175" width="330" height="90"/><path d="M95 275v30m330-30v30M85 60H55m30 65H55m380 50h35m-35 90h35" opacity=".45"/><path d="M100 295h320M65 65v55m375 60v80" marker-start="url(#${id}-arrow)" marker-end="url(#${id}-arrow)"/></g><g fill="currentColor" font-family="Manrope, sans-serif" font-size="17"><text x="260" y="38" text-anchor="middle">Вид сверху</text><text x="260" y="158" text-anchor="middle">Вид сбоку</text><text x="260" y="328" text-anchor="middle">Длина ${value('Длина')}</text><text x="35" y="95" text-anchor="middle" transform="rotate(-90 35 95)">Ширина ${value('Ширина')}</text><text x="467" y="226">Высота ${value('Высота')}</text></g></svg><figcaption>Габаритный контур, не изображение конструкции</figcaption></figure></section>`;
}
