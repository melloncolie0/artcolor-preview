(() => {
  const key='artcolor-color-theme-v1';
  const root=document.documentElement;
  const valid=value=>value==='dark'||value==='light';
  const sync=()=>document.querySelectorAll('[data-color-theme-choice]').forEach(button=>{
    button.setAttribute('aria-pressed',String(button.dataset.colorThemeChoice===root.dataset.colorTheme));
  });
  const apply=theme=>{
    root.dataset.colorTheme=theme;
    root.style.colorScheme=theme;
    const meta=document.querySelector('meta[name="theme-color"]');
    if(meta)meta.content=theme==='dark'?'#080a08':'#2d4c3e';
    sync();
  };
  let initial=valid(root.dataset.colorTheme)?root.dataset.colorTheme:'light';
  try{const saved=localStorage.getItem(key);if(valid(saved))initial=saved;}catch{}
  apply(initial);
  document.addEventListener('DOMContentLoaded',sync,{once:true});
  document.addEventListener('click',event=>{
    const button=event.target.closest('[data-color-theme-choice]');
    const theme=button?.dataset.colorThemeChoice;
    if(!valid(theme))return;
    apply(theme);
    try{localStorage.setItem(key,theme);}catch{}
  });
  window.addEventListener('storage',event=>{
    if(event.key===key||event.key===null)apply(event.newValue==='dark'?'dark':'light');
  });
})();
